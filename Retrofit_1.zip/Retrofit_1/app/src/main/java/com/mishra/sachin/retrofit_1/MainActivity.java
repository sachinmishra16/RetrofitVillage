package com.mishra.sachin.retrofit_1;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Query;

public class MainActivity extends AppCompatActivity {

    TextView textView;

    SSLN_API apiService = ApiClient.getClient().create(SSLN_API.class);  //to make a connenction

    String data="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView=findViewById(R.id.textid);
        new GetData().execute();

    }

    public class GetData extends AsyncTask<Void,Void,Boolean>
    {

        @Override
        protected Boolean doInBackground(Void... voids)
        {
            Call<ArrayList<Model>> call =apiService.getVillageForCamp("user");

            try
            {
                ArrayList<Model> models= call.execute().body();

                for(Model model:models)
                {
                    data=data+"\t"+ "User Name : "+model.getUserFullname()+"\n"+"\n";

                    //Toast.makeText(MainActivity.this, "hihi "+model.getVillageName(), Toast.LENGTH_SHORT).show();
                }



            } catch (IOException e)
            {
                e.printStackTrace();
            }

            return true;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {


            super.onPostExecute(aBoolean);

            textView.setText(data);
        }
    }

    }

