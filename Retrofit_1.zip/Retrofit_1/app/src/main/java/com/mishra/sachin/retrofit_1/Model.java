package com.mishra.sachin.retrofit_1;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Model
{

    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("user_fullname")
    @Expose
    private String userFullname;
    @SerializedName("user_contact")
    @Expose
    private String userContact;
    @SerializedName("user_email")
    @Expose
    private String userEmail;
    @SerializedName("user_profile_img")
    @Expose
    private String userProfileImg;
    @SerializedName("role_id")
    @Expose
    private String roleId;
    @SerializedName("gender")
    @Expose
    private String gender;
    @SerializedName("ref_id")
    @Expose
    private String refId;
    @SerializedName("ref_type")
    @Expose
    private String refType;
    @SerializedName("village_access")
    @Expose
    private String villageAccess;
    @SerializedName("target")
    @Expose
    private String target;
    @SerializedName("created_on")
    @Expose
    private String createdOn;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("del_action")
    @Expose
    private String delAction;
    @SerializedName("is_head")
    @Expose
    private String isHead;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserFullname() {
        return userFullname;
    }

    public void setUserFullname(String userFullname) {
        this.userFullname = userFullname;
    }

    public String getUserContact() {
        return userContact;
    }

    public void setUserContact(String userContact) {
        this.userContact = userContact;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserProfileImg() {
        return userProfileImg;
    }

    public void setUserProfileImg(String userProfileImg) {
        this.userProfileImg = userProfileImg;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getRefType() {
        return refType;
    }

    public void setRefType(String refType) {
        this.refType = refType;
    }

    public String getVillageAccess() {
        return villageAccess;
    }

    public void setVillageAccess(String villageAccess) {
        this.villageAccess = villageAccess;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDelAction() {
        return delAction;
    }

    public void setDelAction(String delAction) {
        this.delAction = delAction;
    }

    public String getIsHead() {
        return isHead;
    }

    public void setIsHead(String isHead) {
        this.isHead = isHead;
    }


}
