package com.mishra.sachin.retrofit_1;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface SSLN_API
{
    @POST("download_general.php")
    Call<ArrayList<Model>> getVillageForCamp(@Query("table_name") String tableName);



}
